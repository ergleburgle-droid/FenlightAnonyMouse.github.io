# -*- coding: utf-8 -*-
import requests
from caches.settings_cache import get_setting
# from modules.kodi_utils import logger

class MDBListAPI:
	BASE = 'https://mdblist.com/api/'

	def __init__(self):
		self.api_key = get_setting('fenlight.mdblist_api', 'empty_setting')

	def _get(self, endpoint, params=None):
		if params is None:
			params = {}
		params['apikey'] = self.api_key
		try:
			response = requests.get('%s%s' % (self.BASE, endpoint), params=params, timeout=20)
			response.raise_for_status()
			return response.json()
		except:
			return None

	def top_lists(self):
		# GET /lists/?apikey=KEY — returns top/popular public lists
		# Each list has: id, name, slug, user_name, mediatype ('movie'|'show'), count, likes
		return self._get('lists/')

	def user_lists(self):
		# GET /lists/user/?apikey=KEY — returns user's own lists (requires api key)
		return self._get('lists/user/')

	def list_items(self, list_id):
		# GET /lists/LIST_ID/items?apikey=KEY — returns items in a list
		# Each item has: id (imdb_id format), imdb_id, tmdb_id, title, year, mediatype
		return self._get('lists/%s/items' % list_id)

	def search_lists(self, query):
		# GET /lists/search/?s=QUERY&apikey=KEY — search public lists
		return self._get('lists/search/', params={'s': query})

	def ratings(self, imdb_id):
		# GET /?i=IMDB_ID&apikey=KEY — get ratings for a title
		# Returns: imdbrating, tomatoesmeter, metacritic, tmdbid, type, year, title
		return self._get('', params={'i': imdb_id})

mdblist_api = MDBListAPI()
