# -*- coding: utf-8 -*-
import sys
from apis.mdblist_api import MDBListAPI
from modules import kodi_utils
# from modules.kodi_utils import logger

def _no_api_key(handle):
	kodi_utils.notification('Please set your MDBList API key in Settings > Accounts')
	kodi_utils.set_content(handle, 'files')
	kodi_utils.end_directory(handle)

def mdblist_top_lists(params):
	"""Shows top public MDBList lists as a browsable directory."""
	def _builder():
		for item in data:
			try:
				list_id = item.get('id')
				list_name = item.get('name', '')
				list_count = item.get('count', 0)
				list_likes = item.get('likes', 0)
				mediatype = item.get('mediatype', '')
				user_name = item.get('user_name', '')
				if not list_id or not list_name:
					continue
				display = '[B]%s[/B] [I](%s x%s)[/I]' % (list_name, user_name, list_count)
				url = kodi_utils.build_url({
					'mode': 'mdblist.mdblist_list_contents',
					'list_id': str(list_id),
					'list_name': list_name,
					'mediatype': mediatype
				})
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': lists_icon, 'poster': lists_icon, 'thumb': lists_icon, 'fanart': fanart, 'banner': fanart})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot('[B]%s[/B][CR]Items: %s | Likes: %s' % (list_name, list_count, list_likes))
				yield (url, listitem, True)
			except:
				pass

	handle = int(sys.argv[1])
	lists_icon = kodi_utils.get_icon('lists')
	fanart = kodi_utils.get_addon_fanart()
	api = MDBListAPI()
	if api.api_key in ('empty_setting', '', None):
		return _no_api_key(handle)
	try:
		data = api.top_lists() or []
		kodi_utils.add_items(handle, list(_builder()))
	except:
		pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, 'MDBList - Top Lists')
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')


def mdblist_list_contents(params):
	"""Shows items in a specific MDBList list directly as movie/show entries."""
	def _builder():
		for item in items:
			try:
				tmdb_id = item.get('tmdb_id') or item.get('tmdbid')
				title = item.get('title', '')
				year = item.get('year', '')
				mediatype = item.get('mediatype', '') or item.get('type', '')
				if not tmdb_id or not title:
					continue
				if year:
					display = '[B]%s[/B] (%s)' % (title, year)
				else:
					display = '[B]%s[/B]' % title
				if mediatype == 'show':
					icon = tv_icon
					url = kodi_utils.build_url({
						'mode': 'build_tvshow_list',
						'action': 'mdblist_item',
						'key_id': str(tmdb_id),
						'name': title
					})
				else:
					icon = movies_icon
					url = kodi_utils.build_url({
						'mode': 'build_movie_list',
						'action': 'mdblist_item',
						'key_id': str(tmdb_id),
						'name': title
					})
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': icon, 'poster': icon, 'thumb': icon, 'fanart': fanart, 'banner': fanart})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setTitle(title)
				if year:
					try:
						info_tag.setYear(int(year))
					except:
						pass
				info_tag.setPlot(' ')
				yield (url, listitem, True)
			except:
				pass

	handle = int(sys.argv[1])
	list_id = params.get('list_id')
	list_name = params.get('list_name', 'MDBList')
	movies_icon = kodi_utils.get_icon('movies')
	tv_icon = kodi_utils.get_icon('tv')
	fanart = kodi_utils.get_addon_fanart()
	api = MDBListAPI()
	if api.api_key in ('empty_setting', '', None):
		return _no_api_key(handle)
	try:
		result = api.list_items(list_id) or []
		# MDBList may return a dict with an 'items' key or a bare list
		if isinstance(result, dict):
			items = result.get('items', [])
		else:
			items = result
		kodi_utils.add_items(handle, list(_builder()))
	except:
		pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, list_name)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.movies')


def mdblist_search_lists(params):
	"""Search public MDBList lists and display results as a browsable directory."""
	def _builder():
		for item in data:
			try:
				list_id = item.get('id')
				list_name = item.get('name', '')
				list_count = item.get('count', 0)
				user_name = item.get('user_name', '')
				if not list_id or not list_name:
					continue
				display = '[B]%s[/B] [I](%s x%s)[/I]' % (list_name, user_name, list_count)
				url = kodi_utils.build_url({
					'mode': 'mdblist.mdblist_list_contents',
					'list_id': str(list_id),
					'list_name': list_name
				})
				listitem = kodi_utils.make_listitem()
				listitem.setLabel(display)
				listitem.setArt({'icon': lists_icon, 'poster': lists_icon, 'thumb': lists_icon, 'fanart': fanart, 'banner': fanart})
				info_tag = listitem.getVideoInfoTag()
				info_tag.setPlot('[B]%s[/B][CR]Items: %s' % (list_name, list_count))
				yield (url, listitem, True)
			except:
				pass

	handle = int(sys.argv[1])
	query = params.get('key_id') or params.get('query', '')
	lists_icon = kodi_utils.get_icon('lists')
	fanart = kodi_utils.get_addon_fanart()
	api = MDBListAPI()
	if api.api_key in ('empty_setting', '', None):
		return _no_api_key(handle)
	try:
		data = api.search_lists(query) or []
		if isinstance(data, dict):
			data = data.get('results', data.get('lists', []))
		kodi_utils.add_items(handle, list(_builder()))
	except:
		pass
	kodi_utils.set_content(handle, 'files')
	kodi_utils.set_category(handle, 'MDBList Search: %s' % query)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.main')
