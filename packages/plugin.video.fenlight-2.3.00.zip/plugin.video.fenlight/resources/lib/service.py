# -*- coding: utf-8 -*-
from xbmc import Monitor
import os
import json
import inspect
from time import time
from threading import Thread
from caches.settings_cache import get_setting, set_setting, sync_settings
from modules import kodi_utils

pause_services_prop = 'fenlight.pause_services'
firstrun_update_prop = 'fenlight.firstrun_update'
current_skin_prop = 'fenlight.current_skin'
trakt_service_string = 'TraktMonitor Service Update %s - %s'
trakt_success_line_dict = {'success': 'Trakt Update Performed', 'no account': '(Unauthorized) Trakt Update Performed'}
update_string = 'Next Update in %s minutes...'

class SetAddonConstants:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'SetAddonConstants Service Starting')
		import random
		addon_items = [
			('fenlight.playback_key', str(random.randint(1000, 10000))),
			('fenlight.addon_version', kodi_utils.addon_info('version')),
			('fenlight.addon_path', kodi_utils.addon_info('path')),
			('fenlight.addon_profile', kodi_utils.translate_path(kodi_utils.addon_info('profile'))),
			('fenlight.addon_icon', kodi_utils.translate_path(kodi_utils.addon_info('icon'))),
			('fenlight.addon_icon_mini', kodi_utils.addon_icon_mini()),
			('fenlight.addon_fanart', kodi_utils.addon_fanart())
		]
		for item in addon_items: kodi_utils.set_property(*item)
		return kodi_utils.logger('Fenlight Gold', 'SetAddonConstants Service Finished')

class DatabaseMaintenance:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'DatabaseMaintenance Service Starting')
		from caches.base_cache import check_databases_integrity
		check_databases_integrity(silent=True)
		return kodi_utils.logger('Fenlight Gold', 'DatabaseMaintenance Service Finished')

class SyncSettings:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'SyncSettings Service Starting')
		sync_settings()
		return kodi_utils.logger('Fenlight Gold', 'SyncSettings Service Finished')

class MigrateSettings:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'MigrateSettings Service Starting')
		old_usernames = ('FenlightAnonyMouse', 'empty_setting', '')
		if get_setting('fenlight.update.username', 'empty_setting') in old_usernames:
			set_setting('update.username', 'ergleburgle-droid')
			set_setting('update.location', 'FenlightGold')
			set_setting('update.branch', 'main')
			kodi_utils.logger('Fenlight Gold', 'MigrateSettings: updater settings migrated to FenlightGold')
		old_fanarts = ('fenlightam_fanart.jpg', 'fenlight_fanart_01.jpg', 'empty_setting', '')
		current_fanart = get_setting('fenlight.default_addon_fanart', 'empty_setting')
		if any(current_fanart.endswith(f) for f in old_fanarts):
			import xbmcaddon
			new_fanart = xbmcaddon.Addon('plugin.video.fenlight').getAddonInfo('fanart')
			set_setting('default_addon_fanart', new_fanart)
			kodi_utils.logger('Fenlight Gold', 'MigrateSettings: fanart migrated to %s' % new_fanart)
		kodi_utils.logger('Fenlight Gold', 'MigrateSettings Service Finished')

class OnUpdateChanges:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'OnUpdateChanges Service Starting')
		try:
			for method in list(filter(lambda x: x[0] != 'run', inspect.getmembers(OnUpdateChanges, predicate=inspect.isfunction))):
				if not get_setting('fenlight.updatechecks.%s' % method[0], 'false') == 'true':
					method[1](self)
					set_setting('updatechecks.%s' % method[0], 'true')
		except: pass
		return kodi_utils.logger('Fenlight Gold', 'OnUpdateChanges Service Finished')

	def refresh_addon_keys(self):
		from caches.trakt_cache import clear_all_trakt_cache_data
		from caches.tmdb_lists import tmdb_lists_cache
		from caches.settings_cache import restore_setting_default
		show_dialog = False
		if get_setting('fenlight.tmdb_api') == 'b370b60447737762ca38457bd77579b3':
			restore_setting_default({'silent': 'true', 'setting_id': 'tmdb_api'})
			set_setting('tmdb.token', 'empty_setting')
			set_setting('tmdb.account_id', 'empty_setting')
			set_setting('tmdb.username', 'empty_setting')
			set_setting('tmdb.session_id', 'empty_setting')
			set_setting('tmdb.account_session_id', 'empty_setting')
			tmdb_lists_cache.clear_all()
			show_dialog = True
		if get_setting('fenlight.trakt.client') == '1038ef327e86e7f6d39d80d2eb5479bff66dd8394e813c5e0e387af0f84d89fb':
			restore_setting_default({'silent': 'true', 'setting_id': 'trakt.client'})
			set_setting('trakt.user', 'empty_setting')
			set_setting('trakt.expires', '0')
			set_setting('trakt.token', '0')
			set_setting('trakt.refresh', '0')
			set_setting('trakt.next_daily_clear', '0')
			set_setting('watched_indicators', '0')
			clear_all_trakt_cache_data(silent=True, refresh=False)
			show_dialog = True
		if show_dialog:
			kodi_utils.ok_dialog(heading='Fenlight Gold — Credentials Reset',
				text='The original developer revoked the shared TMDb and Trakt API keys. '
				'Please re-authenticate your Trakt and TMDb accounts in '
				'Fenlight Gold Settings > Accounts.')

class CustomWindowsPrepare:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'CustomWindowsPrepare Service Starting')
		from windows.base_window import FontUtils, ExtrasUtils
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		kodi_utils.clear_property(current_skin_prop)
		ExtrasUtils().run()
		font_utils = FontUtils()
		while not monitor.abortRequested():
			font_utils.execute_custom_fonts()
			wait_for_abort(20)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('Fenlight Gold', 'CustomWindowsPrepare Service Finished')

class TraktMonitor:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'TraktMonitor Service Starting')
		from apis.trakt_api import trakt_sync_activities
		from modules.settings import trakt_user_active, trakt_sync_interval
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': wait_for_abort(10)
			wait_time = 1800
			try:
				sync_interval, wait_time = trakt_sync_interval()
				next_update_string = update_string % sync_interval
				if trakt_user_active: status = trakt_sync_activities()
				else: status = 'no_auth'
				if status == 'failed': kodi_utils.logger('Fenlight Gold', trakt_service_string % ('Failed. Error from Trakt', next_update_string))
				elif status == 'no_auth': kodi_utils.logger('Fenlight Gold', trakt_service_string % ('Not Run. No Current Trakt Account', next_update_string))
				else:
					if status in ('success', 'no account'):
						kodi_utils.logger('Fenlight Gold', trakt_service_string % ('Success. %s' % trakt_success_line_dict[status], next_update_string))
					else:
						kodi_utils.logger('Fenlight Gold', trakt_service_string % ('Success. No Changes Needed', next_update_string))
					if status == 'success' and get_setting('fenlight.trakt.refresh_widgets', 'false') == 'true':
						kodi_utils.run_plugin({'mode': 'kodi_refresh'})
			except Exception as e: kodi_utils.logger('Fenlight Gold', trakt_service_string % ('Failed', 'The following Error Occured: %s' % str(e)))
			wait_for_abort(wait_time)
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('Fenlight Gold', 'TraktMonitor Service Finished')

class UpdateCheck:
	def run(self):
		if kodi_utils.get_property(firstrun_update_prop) == 'true': return
		kodi_utils.logger('Fenlight Gold', 'UpdateCheck Service Starting')
		from modules.updater import update_check
		from modules.settings import update_action, update_delay
		end_pause = time() + update_delay()
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, is_playing = monitor.waitForAbort, player.isPlayingVideo
		while not monitor.abortRequested():
			while time() < end_pause: wait_for_abort(1)
			while kodi_utils.get_property(pause_services_prop) == 'true' or is_playing(): wait_for_abort(1)
			update_check(update_action())
			break
		kodi_utils.set_property(firstrun_update_prop, 'true')
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('Fenlight Gold', 'UpdateCheck Service Finished')

class WidgetRefresher:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'WidgetRefresher Service Starting')
		monitor, player = kodi_utils.kodi_monitor(), kodi_utils.kodi_player()
		wait_for_abort, self.is_playing = monitor.waitForAbort, player.isPlayingVideo
		wait_for_abort(10)
		self.set_next_refresh(time())
		while not monitor.abortRequested():
			try:
				wait_for_abort(10)
				offset = int(get_setting('fenlight.widget_refresh_timer', '60'))
				if offset != self.offset:
					self.set_next_refresh(time())
					continue
				if self.condition_check(): continue
				if self.next_refresh < time():
					kodi_utils.logger('Fenlight Gold', 'WidgetRefresher Service - Widgets Refreshed')
					kodi_utils.refresh_widgets()
					self.set_next_refresh(time())
			except: pass
		try: del monitor
		except: pass
		try: del player
		except: pass
		return kodi_utils.logger('Fenlight Gold', 'WidgetRefresher Service Finished')

	def condition_check(self):
		if not self.external(): return True
		if self.next_refresh == None or self.is_playing() or kodi_utils.get_property(pause_services_prop) == 'true': return True
		if kodi_utils.get_property('fenlight.window_loaded') == 'true': return True
		try:
			window_stack = json.loads(kodi_utils.get_property('fenlight.window_stack'))
			if window_stack or window_stack == []: return True
		except: pass
		return False

	def set_next_refresh(self, _time):
		self.offset = int(get_setting('fenlight.widget_refresh_timer', '60'))
		if self.offset: self.next_refresh = _time + (self.offset*60)
		else: self.next_refresh = None

	def external(self):
		return 'plugin' not in kodi_utils.get_infolabel('Container.PluginName')

class FirstRunSetup:
	PROP = 'fenlight.firstrun_setup_shown'

	def run(self):
		if kodi_utils.get_property(self.PROP) == 'true': return
		kodi_utils.set_property(self.PROP, 'true')
		tmdb_key = get_setting('fenlight.tmdb_api', 'empty_setting')
		if tmdb_key not in ('empty_setting', '', None): return
		kodi_utils.logger('Fenlight Gold', 'FirstRunSetup: no TMDb key — showing setup dialog')
		kodi_utils.ok_dialog(
			heading='Fenlight Gold — First Run Setup',
			text='[B]Welcome![/B] To get started you need a free TMDb API key.[CR][CR]'
			'1. Visit [B]themoviedb.org[/B] and create a free account[CR]'
			'2. Go to [B]Settings > API[/B] and request a key (select Personal/Hobby)[CR]'
			'3. Open Fenlight Gold [B]Settings > Accounts > TMDb API > API Key[/B] and paste it[CR][CR]'
			'For TMDb Lists, also paste the [B]API Read Access Token (v4 auth)[/B] from the same page.[CR]'
			'For Trakt, Debrid and other services, also visit Settings > Accounts.')

class AutoStart:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'AutoStart Service Starting')
		from modules.settings import auto_start_fenlight
		if auto_start_fenlight(): kodi_utils.run_addon()
		return kodi_utils.logger('Fenlight Gold', 'AutoStart Service Finished')

class AddonXMLCheck:
	def run(self):
		kodi_utils.logger('Fenlight Gold', 'AddonXMLCheck Service Starting')
		from xml.dom.minidom import parse as mdParse
		self.addon_xml = kodi_utils.translate_path('special://home/addons/plugin.video.fenlight/addon.xml')
		self.root = mdParse(self.addon_xml)
		self.change_list = []
		self.check_property('reuse_language_invoker', 'reuselanguageinvoker')
		self.change_xml_file()
		return kodi_utils.logger('Fenlight Gold', 'AddonXMLCheck Service Finished')

	def check_property(self, setting, tag_name):
		current_addon_setting = get_setting('fenlight.%s' % setting, None)
		if current_addon_setting is None: return
		tag_instance = self.root.getElementsByTagName(tag_name)[0].firstChild
		current_property = tag_instance.data
		if current_property != current_addon_setting:
			tag_instance.data = current_addon_setting
			self.change_list.append(tag_name)

	def change_xml_file(self):
		if not self.change_list: return
		kodi_utils.notification('Refreshing Addon XML. Restarting Addons')
		new_xml = str(self.root.toxml()).replace('<?xml version="1.0" ?>', '')
		with open(self.addon_xml, 'w') as f: f.write(new_xml)
		kodi_utils.logger('Fenlight Gold', 'AddonXMLCheck Service - Change Detected. Restarting Addons')
		kodi_utils.execute_builtin('ActivateWindow(Home)', True)
		kodi_utils.update_local_addons()
		kodi_utils.disable_enable_addon()

class FenLightMonitor(Monitor):
	def __init__ (self):
		Monitor.__init__(self)
		self.startServices()

	def startServices(self):
		for cls in (SetAddonConstants, DatabaseMaintenance, SyncSettings, MigrateSettings, OnUpdateChanges, AddonXMLCheck):
			try: cls().run()
			except Exception as e: kodi_utils.logger('Fenlight Gold', 'Service Error [%s]: %s' % (cls.__name__, str(e)))
		Thread(target=CustomWindowsPrepare().run).start()
		Thread(target=TraktMonitor().run).start()
		Thread(target=UpdateCheck().run).start()
		Thread(target=WidgetRefresher().run).start()
		Thread(target=FirstRunSetup().run).start()
		try: AutoStart().run()
		except Exception as e: kodi_utils.logger('Fenlight Gold', 'Service Error [AutoStart]: %s' % str(e))

	def onNotification(self, sender, method, data):
		if method in ('GUI.OnScreensaverActivated', 'System.OnSleep'):
			kodi_utils.set_property(pause_services_prop, 'true')
			kodi_utils.logger('OnNotificationActions', 'PAUSING Fenlight Gold Services Due to Device Sleep')
		elif method in ('GUI.OnScreensaverDeactivated', 'System.OnWake'):
			kodi_utils.clear_property(pause_services_prop)
			kodi_utils.logger('OnNotificationActions', 'UNPAUSING Fenlight Gold Services Due to Device Awake')

kodi_utils.logger('Fenlight Gold', 'Main Monitor Service Starting')
FenLightMonitor().waitForAbort()
kodi_utils.logger('Fenlight Gold', 'Main Monitor Service Finished')
