# -*- coding: utf-8 -*-
import sys
from datetime import datetime
from caches.settings_cache import get_setting
from modules import kodi_utils

_DAYS = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
_MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def _country():
	cc = get_setting('fenlight.home_country_code', 'GB')
	return 'GB' if cc in (None, '', 'empty_setting') else cc.upper()


def _format_time(airtime):
	try:
		h, m = map(int, airtime.split(':'))
		ampm = 'am' if h < 12 else 'pm'
		return '%d:%02d%s' % (h % 12 or 12, m, ampm)
	except:
		return airtime


def _format_date(airdate):
	try:
		dt = datetime.strptime(airdate, '%Y-%m-%d')
		return '%s %d %s' % (_DAYS[dt.weekday()], dt.day, _MONTHS[dt.month - 1])
	except:
		return airdate


def _build_schedule_items(episodes, handle, show_date=False):
	from apis.tvmaze_api import strip_html
	build_url = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart = kodi_utils.get_addon_fanart()
	items = []
	seen = set()
	for ep in episodes:
		try:
			show = ep.get('show') or {}
			show_id = show.get('id')
			show_name = show.get('name', '')
			if not show_id or not show_name:
				continue
			airdate = ep.get('airdate', '')
			# For today/streaming views deduplicate by show; for week view allow one per show-per-day
			dedup_key = (show_id, airdate) if show_date else show_id
			if dedup_key in seen:
				continue
			seen.add(dedup_key)

			img = show.get('image') or {}
			poster = img.get('medium') or img.get('original') or fanart
			network = (show.get('network') or show.get('webChannel') or {}).get('name', '')
			ep_season = ep.get('season')
			ep_num = ep.get('number')
			ep_name = ep.get('name', '')
			airtime = ep.get('airtime', '')
			ep_summary = strip_html(ep.get('summary', ''))
			show_summary = strip_html(show.get('summary', ''))
			genres = show.get('genres') or []
			rating = (show.get('rating') or {}).get('average') or 0

			header_parts = []
			if show_date and airdate:
				header_parts.append(_format_date(airdate))
			if airtime:
				header_parts.append(_format_time(airtime))
			if network:
				header_parts.append(network)
			header = ' • '.join(header_parts)

			ep_tag = ''
			if ep_season and ep_num:
				ep_tag = 'S%02dE%02d' % (ep_season, ep_num)
				if ep_name:
					ep_tag += ' — %s' % ep_name

			plot_parts = []
			if header:
				plot_parts.append('[B]%s[/B]' % header)
			if ep_tag:
				plot_parts.append(ep_tag)
			plot_parts.append(ep_summary or show_summary)
			plot = '[CR]'.join(filter(None, plot_parts))

			label = ('%s — %s' % (show_name, _format_date(airdate))) if show_date and airdate else show_name
			url = build_url({'mode': 'tvmaze.tvmaze_show_episodes',
							 'show_id': str(show_id), 'show_name': show_name})
			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart})
			info = listitem.getVideoInfoTag()
			info.setTitle(show_name)
			info.setPlot(plot)
			info.setGenres(genres)
			if rating:
				info.setRating(float(rating))
			if airdate:
				info.setFirstAired(airdate)
			if ep_season:
				info.setSeason(int(ep_season))
			if ep_num:
				info.setEpisode(int(ep_num))
			items.append((url, listitem, True))
		except:
			pass
	kodi_utils.add_items(handle, items)


def _finish(handle, content, category):
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, category)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.%s' % content, content)


def tvmaze_schedule_today(params):
	from apis.tvmaze_api import schedule_today
	handle = int(sys.argv[1])
	country = _country()
	kodi_utils.show_busy_dialog()
	episodes = schedule_today(country)
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle, show_date=False)
	_finish(handle, 'tvshows', 'TV Schedule — Today (%s)' % country)


def tvmaze_schedule_streaming(params):
	from apis.tvmaze_api import schedule_web_today
	handle = int(sys.argv[1])
	kodi_utils.show_busy_dialog()
	episodes = schedule_web_today()
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle, show_date=False)
	_finish(handle, 'tvshows', 'Streaming Schedule — Today')


def tvmaze_schedule_week(params):
	from apis.tvmaze_api import schedule_week
	handle = int(sys.argv[1])
	country = _country()
	kodi_utils.show_busy_dialog()
	episodes = schedule_week(country)
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle, show_date=True)
	_finish(handle, 'tvshows', 'TV Schedule — This Week (%s)' % country)


def tvmaze_show_episodes(params):
	from apis.tvmaze_api import show_episodes, strip_html
	handle = int(sys.argv[1])
	show_id = params.get('show_id')
	show_name = params.get('show_name', 'TV Show')
	if not show_id:
		return _finish(handle, 'episodes', show_name)
	kodi_utils.show_busy_dialog()
	episodes = show_episodes(show_id)
	kodi_utils.hide_busy_dialog()
	build_url = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart = kodi_utils.get_addon_fanart()
	items = []
	for ep in episodes:
		try:
			season = ep.get('season', 0)
			number = ep.get('number', 0)
			name = ep.get('name', '')
			airdate = ep.get('airdate', '')
			summary = strip_html(ep.get('summary', ''))
			img = ep.get('image') or {}
			thumb = img.get('medium') or img.get('original') or fanart
			label = 'S%02dE%02d — %s' % (season, number, name) if name else 'S%02dE%02d' % (season, number)
			plot_parts = []
			if airdate:
				plot_parts.append('[B]Aired: %s[/B]' % _format_date(airdate))
			if summary:
				plot_parts.append(summary)
			plot = '[CR]'.join(filter(None, plot_parts))
			url = build_url({'mode': 'tvmaze.tvmaze_episode_info',
							 'title': label, 'plot': plot})
			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': thumb, 'thumb': thumb, 'fanart': fanart})
			info = listitem.getVideoInfoTag()
			info.setTitle(name or label)
			info.setTvShowTitle(show_name)
			info.setSeason(int(season))
			info.setEpisode(int(number))
			info.setPlot(plot)
			if airdate:
				info.setFirstAired(airdate)
			items.append((url, listitem, False))
		except:
			pass
	kodi_utils.add_items(handle, items)
	_finish(handle, 'episodes', '%s — Episodes' % show_name)


def tvmaze_episode_info(params):
	title = params.get('title', '')
	plot = params.get('plot', '')
	kodi_utils.ok_dialog(heading=title, text=plot or 'No description available.')
