# -*- coding: utf-8 -*-
import sys
from datetime import datetime
from modules import kodi_utils, settings as s

_DAYS = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
_MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')


def _country():
	try:
		from caches.settings_cache import get_setting
		cc = get_setting('fenlight.home_country_code', 'GB')
		return 'GB' if cc in (None, '', 'empty_setting') else cc.upper()
	except:
		return 'GB'


def _format_time(airtime):
	try:
		h, m = map(int, airtime.split(':'))
		return '%d:%02d%s' % (h % 12 or 12, m, 'am' if h < 12 else 'pm')
	except:
		return airtime


def _format_date(airdate):
	try:
		dt = datetime.strptime(airdate, '%Y-%m-%d')
		return '%s %d %s' % (_DAYS[dt.weekday()], dt.day, _MONTHS[dt.month - 1])
	except:
		return airdate


def _get_tmdb_show_id(imdb_id, tvdb_id, api_key):
	from apis.tmdb_api import tvshow_external_id
	for source, ext_id in (('imdb_id', imdb_id), ('tvdb_id', tvdb_id)):
		if not ext_id:
			continue
		try:
			result = tvshow_external_id(source, str(ext_id), api_key)
			if result:
				return result.get('id')
		except:
			pass
	return None


def _build_schedule_items(episodes, handle, show_date=False):
	from apis.tvmaze_api import strip_html
	build_url = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart = kodi_utils.get_addon_fanart()
	items = []
	seen = set()
	for ep in episodes:
		try:
			show = ep.get('show') or {}
			show_id = show.get('id')
			show_name = show.get('name', '')
			if not show_id or not show_name:
				continue
			airdate = ep.get('airdate', '')
			dedup_key = (show_id, airdate) if show_date else show_id
			if dedup_key in seen:
				continue
			seen.add(dedup_key)

			img = show.get('image') or {}
			poster = img.get('medium') or img.get('original') or fanart
			network = (show.get('network') or show.get('webChannel') or {}).get('name', '')
			ep_season, ep_num, ep_name = ep.get('season'), ep.get('number'), ep.get('name', '')
			airtime = ep.get('airtime', '')
			ep_summary = strip_html(ep.get('summary', ''))
			show_summary = strip_html(show.get('summary', ''))
			genres = show.get('genres') or []
			rating = (show.get('rating') or {}).get('average') or 0
			externals = show.get('externals') or {}
			imdb_id = externals.get('imdb', '') or ''
			tvdb_id = str(externals.get('thetvdb', '') or '')

			header_parts = []
			if show_date and airdate:
				header_parts.append(_format_date(airdate))
			if airtime:
				header_parts.append(_format_time(airtime))
			if network:
				header_parts.append(network)
			header = ' • '.join(header_parts)

			ep_tag = ''
			if ep_season and ep_num:
				ep_tag = 'S%02dE%02d' % (ep_season, ep_num)
				if ep_name:
					ep_tag += ' — %s' % ep_name

			plot_parts = []
			if header:
				plot_parts.append('[B]%s[/B]' % header)
			if ep_tag:
				plot_parts.append(ep_tag)
			plot_parts.append(ep_summary or show_summary)
			plot = '[CR]'.join(filter(None, plot_parts))

			label = ('%s — %s' % (show_name, _format_date(airdate))) if show_date and airdate else show_name
			url = build_url({'mode': 'tvmaze.tvmaze_show_episodes', 'show_id': str(show_id),
							 'show_name': show_name, 'imdb_id': imdb_id, 'tvdb_id': tvdb_id})
			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart})
			info = listitem.getVideoInfoTag()
			info.setTitle(show_name)
			info.setPlot(plot)
			info.setGenres(genres)
			if rating:
				info.setRating(float(rating))
			if airdate:
				info.setFirstAired(airdate)
			if ep_season:
				info.setSeason(int(ep_season))
			if ep_num:
				info.setEpisode(int(ep_num))
			items.append((url, listitem, True))
		except:
			pass
	kodi_utils.add_items(handle, items)


def _finish(handle, content, category):
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, category)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.%s' % content, content)


def tvmaze_schedule_today(params):
	from apis.tvmaze_api import schedule_today
	handle = int(sys.argv[1])
	country = _country()
	kodi_utils.show_busy_dialog()
	episodes = schedule_today(country)
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle)
	_finish(handle, 'tvshows', 'Airing Today — %s' % country)


def tvmaze_schedule_streaming(params):
	from apis.tvmaze_api import schedule_web_today
	handle = int(sys.argv[1])
	kodi_utils.show_busy_dialog()
	episodes = schedule_web_today()
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle)
	_finish(handle, 'tvshows', 'Streaming — Today')


def tvmaze_schedule_week(params):
	from apis.tvmaze_api import schedule_week
	handle = int(sys.argv[1])
	country = _country()
	kodi_utils.show_busy_dialog()
	episodes = schedule_week(country)
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle, show_date=True)
	_finish(handle, 'tvshows', 'This Week — %s' % country)


def tvmaze_show_episodes(params):
	from apis.tvmaze_api import show_episodes, show_info, strip_html
	handle = int(sys.argv[1])
	show_id = params.get('show_id')
	show_name = params.get('show_name', 'TV Show')
	imdb_id = params.get('imdb_id', '')
	tvdb_id = params.get('tvdb_id', '')

	if not show_id:
		return _finish(handle, 'episodes', show_name)

	kodi_utils.show_busy_dialog()
	episodes = show_episodes(show_id)

	# Resolve TMDb show ID to bridge into the Fenlight scraper pipeline
	tmdb_show_id = None
	api_key = s.tmdb_api_key()
	if api_key not in (None, '', 'empty_setting'):
		if not imdb_id and not tvdb_id:
			info = show_info(show_id)
			if info:
				ext = info.get('externals') or {}
				imdb_id = ext.get('imdb', '') or ''
				tvdb_id = str(ext.get('thetvdb', '') or '')
		tmdb_show_id = _get_tmdb_show_id(imdb_id, tvdb_id, api_key)

	play_key = s.playback_key() if tmdb_show_id else None
	play_mode = ('playback.%s' % play_key) if play_key else None
	playable = bool(play_mode)
	kodi_utils.hide_busy_dialog()

	build_url = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart = kodi_utils.get_addon_fanart()
	items = []

	for ep in episodes:
		try:
			season = ep.get('season', 0)
			number = ep.get('number', 0)
			if not season or not number:
				continue
			name = ep.get('name', '')
			airdate = ep.get('airdate', '')
			summary = strip_html(ep.get('summary', ''))
			img = ep.get('image') or {}
			thumb = img.get('medium') or img.get('original') or fanart

			label = 'S%02dE%02d — %s' % (season, number, name) if name else 'S%02dE%02d' % (season, number)
			plot_parts = []
			if airdate:
				plot_parts.append('[B]%s[/B]' % _format_date(airdate))
			if summary:
				plot_parts.append(summary)
			plot = '[CR]'.join(filter(None, plot_parts))

			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': thumb, 'thumb': thumb, 'fanart': fanart})
			info = listitem.getVideoInfoTag()
			info.setTitle(name or label)
			info.setTvShowTitle(show_name)
			info.setSeason(int(season))
			info.setEpisode(int(number))
			info.setPlot(plot)
			if airdate:
				info.setFirstAired(airdate)

			if playable:
				url = build_url({'mode': play_mode, 'media_type': 'episode',
								 'tmdb_id': str(tmdb_show_id), 'season': str(season),
								 'episode': str(number), 'playcount': '0',
								 play_key: play_key})
				listitem.setProperty('IsPlayable', 'true')
				items.append((url, listitem, False))
			else:
				url = build_url({'mode': 'tvmaze.tvmaze_episode_info',
								 'title': label, 'plot': plot})
				items.append((url, listitem, True))
		except:
			pass

	if not playable and items:
		notice = make_listitem()
		notice.setLabel('[I]Add a TMDb API key in Settings > Accounts to enable playback[/I]')
		notice.setArt({'fanart': fanart})
		notice.getVideoInfoTag().setPlot(' ')
		items.insert(0, (build_url({'mode': 'tvmaze.tvmaze_episode_info', 'title': '', 'plot': ''}), notice, True))

	kodi_utils.add_items(handle, items)
	_finish(handle, 'episodes', show_name)


def tvmaze_episode_info(params):
	import xbmcplugin
	handle = int(sys.argv[1])
	title = params.get('title', '')
	plot = params.get('plot', '')
	if title or plot:
		kodi_utils.ok_dialog(heading=title or 'Episode Info', text=plot or 'No description available.')
	xbmcplugin.endOfDirectory(handle, succeeded=False)
