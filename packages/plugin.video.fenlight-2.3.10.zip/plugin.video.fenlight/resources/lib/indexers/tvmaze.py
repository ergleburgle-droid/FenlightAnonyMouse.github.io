# -*- coding: utf-8 -*-
import re
import sys
from datetime import datetime, date as _date
from modules import kodi_utils, settings as s

_DAYS   = ('Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday')
_MONTHS = ('Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec')
_STRIP_RE = re.compile(r'<[^>]+>')


# ── Utilities ────────────────────────────────────────────────────────────────

def _strip_html(text):
	return _STRIP_RE.sub('', text or '').strip()

def _today():
	return _date.today()

def _is_aired(airdate):
	if not airdate:
		return False
	try:
		return datetime.strptime(airdate, '%Y-%m-%d').date() <= _today()
	except:
		return False

def _format_time(airtime):
	try:
		h, m = map(int, airtime.split(':'))
		return '%d:%02d%s' % (h % 12 or 12, m, 'am' if h < 12 else 'pm')
	except:
		return airtime

def _format_date(airdate):
	try:
		dt = datetime.strptime(airdate, '%Y-%m-%d')
		return '%s %d %s' % (_DAYS[dt.weekday()], dt.day, _MONTHS[dt.month - 1])
	except:
		return airdate

def _country():
	try:
		from caches.settings_cache import get_setting
		cc = get_setting('fenlight.home_country_code', 'GB')
		return 'GB' if cc in (None, '', 'empty_setting') else cc.upper()
	except:
		return 'GB'


# ── TMDb bridge ──────────────────────────────────────────────────────────────

def _get_tmdb_show_id(imdb_id, tvdb_id, api_key):
	from apis.tmdb_api import tvshow_external_id
	for source, ext_id in (('imdb_id', imdb_id), ('tvdb_id', tvdb_id)):
		if not ext_id:
			continue
		try:
			result = tvshow_external_id(source, str(ext_id), api_key)
			if result:
				return result.get('id')
		except:
			pass
	return None

def _resolve_playback(show_id, imdb_id, tvdb_id):
	"""Return (tmdb_show_id, play_key, play_mode) or (None, None, None)."""
	api_key = s.tmdb_api_key()
	if api_key in (None, '', 'empty_setting'):
		return None, None, None
	if not imdb_id and not tvdb_id:
		from apis.tvmaze_api import show_info
		info = show_info(show_id)
		if info:
			ext = info.get('externals') or {}
			imdb_id = ext.get('imdb', '') or ''
			tvdb_id = str(ext.get('thetvdb', '') or '')
	tmdb_id = _get_tmdb_show_id(imdb_id, tvdb_id, api_key)
	if not tmdb_id:
		return None, None, None
	play_key = s.playback_key()
	return tmdb_id, play_key, 'playback.%s' % play_key


# ── Episode item builder ─────────────────────────────────────────────────────

def _episode_item(ep, show_name, tmdb_show_id, play_key, play_mode,
				  fanart, build_url, make_listitem, tonight_pin=False):
	"""
	Build a single (url, listitem, is_folder) tuple for one episode.

	tonight_pin=True: marks this item as the "Airing Tonight" header — always
	non-playable regardless of TMDb key, displayed with a gold label.
	"""
	season  = ep.get('season', 0)
	number  = ep.get('number', 0)
	if not season or not number:
		return None
	name    = ep.get('name', '')
	airdate = ep.get('airdate', '')
	summary = _strip_html(ep.get('summary', ''))
	img     = ep.get('image') or {}
	thumb   = img.get('medium') or img.get('original') or fanart
	aired   = _is_aired(airdate) and not tonight_pin

	ep_ref = 'S%02dE%02d' % (season, number)
	ep_ref_full = ('%s — %s' % (ep_ref, name)) if name else ep_ref

	# Label
	if tonight_pin:
		label = '[COLOR gold][B]Airing Tonight:[/B][/COLOR] %s' % ep_ref_full
	elif not aired:
		label = '[COLOR grey]%s[/COLOR]' % ep_ref_full
	else:
		label = ep_ref_full

	# Plot
	plot_parts = []
	if airdate:
		date_str = _format_date(airdate)
		plot_parts.append('[B]%s[/B]' % (('Airing: %s' % date_str) if not aired else date_str))
	if summary:
		plot_parts.append(summary)
	if not (aired or tonight_pin) and not play_mode:
		plot_parts.append('[I]Add a TMDb API key in Settings > Accounts to enable playback.[/I]')
	plot = '[CR]'.join(filter(None, plot_parts))

	listitem = make_listitem()
	listitem.setLabel(label)
	listitem.setArt({'icon': thumb, 'thumb': thumb, 'fanart': fanart})
	info_tag = listitem.getVideoInfoTag()
	info_tag.setTitle(name or ep_ref_full)
	info_tag.setTvShowTitle(show_name)
	info_tag.setSeason(int(season))
	info_tag.setEpisode(int(number))
	info_tag.setPlot(plot)
	if airdate:
		info_tag.setFirstAired(airdate)

	# URL: playable only for aired episodes when we have a TMDb ID
	if aired and play_mode and tmdb_show_id:
		url = build_url({'mode': play_mode, 'media_type': 'episode',
						 'tmdb_id': str(tmdb_show_id), 'season': str(season),
						 'episode': str(number), 'playcount': '0',
						 play_key: play_key})
		listitem.setProperty('IsPlayable', 'true')
		return (url, listitem, False)
	else:
		url = build_url({'mode': 'tvmaze.tvmaze_episode_info',
						 'title': ep_ref_full, 'plot': plot})
		return (url, listitem, True)


# ── Schedule view ────────────────────────────────────────────────────────────

def _build_schedule_items(episodes, handle, show_date=False):
	build_url   = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart      = kodi_utils.get_addon_fanart()
	run_plugin  = 'RunPlugin(%s)'
	items = []
	seen  = set()

	for ep in episodes:
		try:
			show     = ep.get('show') or {}
			show_id  = show.get('id')
			show_name = show.get('name', '')
			if not show_id or not show_name:
				continue
			airdate = ep.get('airdate', '')
			dedup_key = (show_id, airdate) if show_date else show_id
			if dedup_key in seen:
				continue
			seen.add(dedup_key)

			img      = show.get('image') or {}
			poster   = img.get('medium') or img.get('original') or fanart
			network  = (show.get('network') or show.get('webChannel') or {}).get('name', '')
			ep_season, ep_num = ep.get('season'), ep.get('number')
			ep_name  = ep.get('name', '')
			airtime  = ep.get('airtime', '')
			ep_sum   = _strip_html(ep.get('summary', ''))
			show_sum = _strip_html(show.get('summary', ''))
			genres   = show.get('genres') or []
			rating   = (show.get('rating') or {}).get('average') or 0
			externals = show.get('externals') or {}
			imdb_id  = externals.get('imdb', '') or ''
			tvdb_id  = str(externals.get('thetvdb', '') or '')

			header_parts = []
			if show_date and airdate:
				header_parts.append(_format_date(airdate))
			if airtime:
				header_parts.append(_format_time(airtime))
			if network:
				header_parts.append(network)
			header = ' • '.join(header_parts)

			ep_tag = ''
			if ep_season and ep_num:
				ep_tag = 'S%02dE%02d' % (ep_season, ep_num)
				if ep_name:
					ep_tag += ' — %s' % ep_name

			plot_parts = []
			if header:
				plot_parts.append('[B]%s[/B]' % header)
			if ep_tag:
				plot_parts.append(ep_tag)
			plot_parts.append(ep_sum or show_sum)
			plot = '[CR]'.join(filter(None, plot_parts))

			label = ('%s — %s' % (show_name, _format_date(airdate))) if show_date and airdate else show_name

			# Primary click → full episode list
			episodes_url = build_url({'mode': 'tvmaze.tvmaze_show_episodes',
									  'show_id': str(show_id), 'show_name': show_name,
									  'imdb_id': imdb_id, 'tvdb_id': tvdb_id})

			# Context menu → Catch Up (navigate into reversed aired-only list)
			catchup_url = build_url({'mode': 'tvmaze.tvmaze_catchup',
									 'show_id': str(show_id), 'show_name': show_name,
									 'imdb_id': imdb_id, 'tvdb_id': tvdb_id,
									 'tonight_season': str(ep_season or ''),
									 'tonight_episode': str(ep_num or ''),
									 'tonight_name': ep_name or ''})
			cm = [('Catch Up — Browse Previous Episodes',
				   'Container.Update(%s)' % catchup_url)]

			listitem = make_listitem()
			listitem.setLabel(label)
			listitem.setArt({'icon': poster, 'poster': poster, 'thumb': poster, 'fanart': fanart})
			listitem.addContextMenuItems(cm)
			info_tag = listitem.getVideoInfoTag()
			info_tag.setTitle(show_name)
			info_tag.setPlot(plot)
			info_tag.setGenres(genres)
			if rating:
				info_tag.setRating(float(rating))
			if airdate:
				info_tag.setFirstAired(airdate)
			if ep_season:
				info_tag.setSeason(int(ep_season))
			if ep_num:
				info_tag.setEpisode(int(ep_num))
			items.append((episodes_url, listitem, True))
		except:
			pass
	kodi_utils.add_items(handle, items)


def _finish(handle, content, category):
	kodi_utils.set_content(handle, content)
	kodi_utils.set_category(handle, category)
	kodi_utils.end_directory(handle)
	kodi_utils.set_view_mode('view.%s' % content, content)


# ── Public entry points ───────────────────────────────────────────────────────

def tvmaze_schedule_today(params):
	from apis.tvmaze_api import schedule_today
	handle = int(sys.argv[1])
	country = _country()
	kodi_utils.show_busy_dialog()
	episodes = schedule_today(country)
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle)
	_finish(handle, 'tvshows', 'Airing Today — %s' % country)


def tvmaze_schedule_streaming(params):
	from apis.tvmaze_api import schedule_web_today
	handle = int(sys.argv[1])
	kodi_utils.show_busy_dialog()
	episodes = schedule_web_today()
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle)
	_finish(handle, 'tvshows', 'Streaming — Today')


def tvmaze_schedule_week(params):
	from apis.tvmaze_api import schedule_week
	handle = int(sys.argv[1])
	country = _country()
	kodi_utils.show_busy_dialog()
	episodes = schedule_week(country)
	kodi_utils.hide_busy_dialog()
	_build_schedule_items(episodes, handle, show_date=True)
	_finish(handle, 'tvshows', 'This Week — %s' % country)


def tvmaze_show_episodes(params):
	"""Full episode list — chronological. Unaired shown in grey, not playable."""
	from apis.tvmaze_api import show_episodes
	handle    = int(sys.argv[1])
	show_id   = params.get('show_id')
	show_name = params.get('show_name', 'TV Show')
	imdb_id   = params.get('imdb_id', '')
	tvdb_id   = params.get('tvdb_id', '')

	if not show_id:
		return _finish(handle, 'episodes', show_name)

	kodi_utils.show_busy_dialog()
	episodes = show_episodes(show_id)
	tmdb_show_id, play_key, play_mode = _resolve_playback(show_id, imdb_id, tvdb_id)
	kodi_utils.hide_busy_dialog()

	build_url    = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart       = kodi_utils.get_addon_fanart()
	items        = []

	for ep in episodes:
		try:
			item = _episode_item(ep, show_name, tmdb_show_id, play_key, play_mode,
								 fanart, build_url, make_listitem)
			if item:
				items.append(item)
		except:
			pass

	if not play_mode and items:
		notice = make_listitem()
		notice.setLabel('[I]Add a TMDb API key in Settings > Accounts to enable playback[/I]')
		notice.setArt({'fanart': fanart})
		notice.getVideoInfoTag().setPlot(' ')
		items.insert(0, (build_url({'mode': 'tvmaze.tvmaze_episode_info',
									'title': '', 'plot': ''}), notice, True))

	kodi_utils.add_items(handle, items)
	_finish(handle, 'episodes', show_name)


def tvmaze_catchup(params):
	"""
	Catch-up view — newest aired episodes first, tonight's episode pinned at top.

	Reached via context menu on schedule items. Lets the user quickly find
	where they left off before watching tonight's new episode.
	"""
	from apis.tvmaze_api import show_episodes
	handle    = int(sys.argv[1])
	show_id   = params.get('show_id')
	show_name = params.get('show_name', 'TV Show')
	imdb_id   = params.get('imdb_id', '')
	tvdb_id   = params.get('tvdb_id', '')

	# Tonight's episode details (for the pinned header item)
	try:
		tonight_season  = int(params.get('tonight_season', 0))
		tonight_episode = int(params.get('tonight_episode', 0))
	except:
		tonight_season = tonight_episode = 0
	tonight_name = params.get('tonight_name', '')

	if not show_id:
		return _finish(handle, 'episodes', show_name)

	kodi_utils.show_busy_dialog()
	all_episodes = show_episodes(show_id)
	tmdb_show_id, play_key, play_mode = _resolve_playback(show_id, imdb_id, tvdb_id)
	kodi_utils.hide_busy_dialog()

	build_url    = kodi_utils.build_url
	make_listitem = kodi_utils.make_listitem
	fanart       = kodi_utils.get_addon_fanart()
	items        = []

	# Separate tonight's episode from the rest
	tonight_ep = None
	aired_eps  = []
	for ep in all_episodes:
		season = ep.get('season', 0)
		number = ep.get('number', 0)
		if not season or not number:
			continue
		if season == tonight_season and number == tonight_episode:
			tonight_ep = ep
		elif _is_aired(ep.get('airdate', '')):
			aired_eps.append(ep)

	# Pin tonight's episode at the top (gold, non-playable)
	if tonight_ep or (tonight_season and tonight_episode):
		pin_ep = tonight_ep or {
			'season': tonight_season, 'number': tonight_episode,
			'name': tonight_name, 'airdate': '', 'summary': '', 'image': {}
		}
		pin_item = _episode_item(pin_ep, show_name, tmdb_show_id, play_key, play_mode,
								 fanart, build_url, make_listitem, tonight_pin=True)
		if pin_item:
			items.append(pin_item)

	# All aired episodes, newest first — these are all playable
	for ep in reversed(aired_eps):
		try:
			item = _episode_item(ep, show_name, tmdb_show_id, play_key, play_mode,
								 fanart, build_url, make_listitem)
			if item:
				items.append(item)
		except:
			pass

	if not play_mode and len(items) > 1:
		notice = make_listitem()
		notice.setLabel('[I]Add a TMDb API key in Settings > Accounts to enable playback[/I]')
		notice.setArt({'fanart': fanart})
		notice.getVideoInfoTag().setPlot(' ')
		items.insert(1, (build_url({'mode': 'tvmaze.tvmaze_episode_info',
									'title': '', 'plot': ''}), notice, True))

	kodi_utils.add_items(handle, items)
	_finish(handle, 'episodes', 'Catch Up — %s' % show_name)


def tvmaze_episode_info(params):
	"""Info dialog for non-playable episodes. Stays on the current list after OK."""
	import xbmcplugin
	handle = int(sys.argv[1])
	title  = params.get('title', '')
	plot   = params.get('plot', '')
	if title or plot:
		kodi_utils.ok_dialog(heading=title or 'Episode Info',
							 text=plot or 'No description available.')
	xbmcplugin.endOfDirectory(handle, succeeded=False)
