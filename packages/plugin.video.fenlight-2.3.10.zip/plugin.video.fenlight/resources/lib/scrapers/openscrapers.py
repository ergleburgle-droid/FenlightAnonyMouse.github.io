# -*- coding: utf-8 -*-
from threading import Thread
from modules.source_utils import internal_results
from modules import kodi_utils

_SCRAPE_PROVIDER = 'openscrapers'
_QUALITY_NORM    = {'4K': '4K', '1080p': '1080p', '1080P': '1080p', '720p': '720p', '720P': '720p',
                    'HD': '720p', 'SD': 'SD', 'SCR': 'SD', 'CAM': 'SD', 'TELE': 'SD'}
_TIMEOUT         = 25


class source:
	def __init__(self):
		self.scrape_provider = _SCRAPE_PROVIDER
		self.sources = []

	def results(self, info):
		try:
			from openscrapers import sources as os_sources
		except ImportError:
			kodi_utils.notification('Free Sources: OpenScrapers not installed', time=4000)
			return []

		try:
			host_dict, host_pr_dict = _build_host_dicts()
			media_type = info.get('media_type', 'movie')
			title      = info.get('title', '')
			year       = info.get('year', '')
			imdb_id    = info.get('imdb_id') or ''
			tvdb_id    = info.get('tvdb_id') or ''
			season     = info.get('season')
			episode    = info.get('episode')
			ep_name    = info.get('ep_name', '')
			aliases    = [a.get('title', '') for a in info.get('aliases', []) if a.get('title')]
			localtitle = aliases[0] if aliases else title
			premiered  = info.get('expiry_times', [''])[0] if info.get('expiry_times') else ''

			scrapers = os_sources()
			scraper_count = len(scrapers) if scrapers else 0
			kodi_utils.logger('Fenlight Gold', 'OpenScrapers: found %d scrapers, host_dict has %d entries' % (scraper_count, len(host_dict)))

			if not scrapers:
				kodi_utils.notification('Free Sources: no scrapers found in OpenScrapers', time=4000)
				return []

			collected = []
			errors = []

			def _run_scraper(name, instance):
				try:
					if media_type == 'movie':
						url_obj = instance.movie(imdb_id, title, localtitle, aliases, year)
					else:
						url_obj = instance.tvshow(imdb_id, tvdb_id, title, localtitle, aliases, year)
						url_obj = instance.episode(url_obj, imdb_id, tvdb_id, ep_name, premiered, season, episode)
					if url_obj is None:
						return
					raw = instance.sources(url_obj, host_dict, host_pr_dict)
					if raw:
						collected.extend(_convert_sources(raw, name))
				except Exception as e:
					errors.append('%s: %s' % (name, str(e)[:60]))

			threads = [Thread(target=_run_scraper, args=(n, inst)) for n, inst in scrapers]
			[t.start() for t in threads]

			import time
			deadline = time.time() + _TIMEOUT
			while any(t.is_alive() for t in threads):
				if time.time() > deadline:
					break
				time.sleep(0.25)

			kodi_utils.logger('Fenlight Gold', 'OpenScrapers: collected %d sources, %d scraper errors' % (len(collected), len(errors)))
			if errors:
				kodi_utils.logger('Fenlight Gold', 'OpenScrapers errors: %s' % ' | '.join(errors[:5]))

			if not collected:
				kodi_utils.notification('Free Sources: 0 results from %d scrapers' % scraper_count, time=4000)

			self.sources = collected
		except Exception as e:
			kodi_utils.logger('Fenlight Gold', 'OpenScrapers outer exception: %s' % str(e))

		internal_results(self.scrape_provider, self.sources)
		return self.sources


def _build_host_dicts():
	try:
		import resolveurl
		resolvers = resolveurl.relevant_resolvers(include_disabled=True, include_universal=False)
		host_dict = list(set(d for r in resolvers for d in getattr(r, 'domains', [])))
		if host_dict:
			return host_dict, []
	except Exception:
		pass
	return [
		'1fichier.com', 'filemoon.sx', 'filemoon.to', 'streamtape.com', 'doodstream.com',
		'mixdrop.co', 'upstream.to', 'voe.sx', 'streamvid.net', 'vidmoly.to',
		'filefactory.com', 'rapidgator.net', 'nitroflare.com', 'turbobit.net',
		'uptobox.com', 'katfile.com', 'mega.nz', 'mediafire.com', 'gofile.io',
		'vidoza.net', 'vudeo.net', 'vidhide.com', 'streamlare.com', 'uqload.co',
		'supervideo.tv', 'userload.co', 'sendvid.com', 'embedsb.com', 'cloudemb.com',
	], []


def _normalise_quality(raw_quality):
	return _QUALITY_NORM.get(raw_quality, 'SD')


def _convert_sources(raw_sources, scraper_name):
	out = []
	for item in raw_sources:
		try:
			if item.get('debridonly'):
				continue
			url = item.get('url', '')
			if not url:
				continue
			quality      = _normalise_quality(item.get('quality', 'SD'))
			hoster       = item.get('source', scraper_name).upper()
			info         = item.get('info', '')
			direct       = bool(item.get('direct', False))
			display_name = ('%s | %s' % (hoster, info)).strip(' |') if info else hoster
			out.append({
				'name':            display_name,
				'display_name':    display_name,
				'quality':         quality,
				'size':            0.0,
				'size_label':      'N/A',
				'debrid':          _SCRAPE_PROVIDER,
				'extraInfo':       display_name,
				'url':             url,
				'id':              url,
				'local':           False,
				'direct':          direct,
				'source':          hoster,
				'scrape_provider': _SCRAPE_PROVIDER,
				'os_scraper':      scraper_name,
			})
		except Exception:
			pass
	return out
