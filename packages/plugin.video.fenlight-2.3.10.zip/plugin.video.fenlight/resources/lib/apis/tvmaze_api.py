# -*- coding: utf-8 -*-
import re
import requests
from datetime import date, timedelta
from modules import kodi_utils
logger = kodi_utils.logger

_BASE = 'https://api.tvmaze.com'


def _get(endpoint, params=None):
	try:
		r = requests.get('%s%s' % (_BASE, endpoint), params=params, timeout=15)
		if r.status_code == 200:
			return r.json()
		if r.status_code == 429:
			logger('TVmaze', 'Rate limited — try again shortly')
	except Exception as e:
		logger('TVmaze', str(e))
	return None


def strip_html(text):
	return re.sub(r'<[^>]+>', '', text or '').strip()


def schedule_today(country='GB'):
	return _get('/schedule', {'country': country, 'date': date.today().isoformat()}) or []


def schedule_web_today():
	return _get('/schedule/web', {'date': date.today().isoformat()}) or []


def schedule_week(country='GB'):
	items, today = [], date.today()
	for i in range(7):
		day = (today + timedelta(days=i)).isoformat()
		items.extend(_get('/schedule', {'country': country, 'date': day}) or [])
	return items


def show_episodes(show_id):
	return _get('/shows/%s/episodes' % show_id) or []
